//
//  JBChartListViewController.h
//  JBChartViewDemo
//
//  Created by Terry Worona on 11/5/13.
//  Copyright (c) 2013 Jawbone. All rights reserved.
//

#import "JBBaseTableViewController.h"

@interface JBChartListViewController : JBBaseTableViewController

@end
