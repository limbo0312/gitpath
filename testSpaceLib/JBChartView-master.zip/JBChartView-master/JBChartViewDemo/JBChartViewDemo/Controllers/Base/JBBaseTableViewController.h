//
//  JBBaseTableViewController.h
//  JBChartViewDemo
//
//  Created by Terry Worona on 11/7/13.
//  Copyright (c) 2013 Jawbone. All rights reserved.
//

#import "JBBaseViewController.h"

@interface JBBaseTableViewController : JBBaseViewController

@property (nonatomic, readonly) UITableView *tableView;

@end
